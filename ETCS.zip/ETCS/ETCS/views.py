from django.shortcuts import render
from django.http import HttpResponse

def login(request):
    return render(request, 'trial.html')
def SELECT(request):
    return render(request, 'SELECT.html')
    
#function with request additional parameter can be passed
#def SELECT(request,args):
#    return render(request,  'SELECT.html')
