from django.shortcuts import render
from django.http import HttpResponse
def login(request):
	return HttpResponse(""" <html>
<form action="SELECT.html" method="POST">
<style>
.brrr {
	background: linear-gradient(270deg, #ee4073, #fec883);
	background-size: 400% 400%;
	-webkit-animation: none;
	-moz-animation: none;
	-o-animation: none;
	animation: none;
	-webkit-animation: GradientAnimation 15s ease infinite;
	-moz-animation: GradientAnimation 15s ease infinite;
	animation: GradientAnimation 15s ease infinite;
	overflow: hidden;
}

.container{
	width: 100vh;
	height: 100vh;
	display: table;
}
.row{
	display: table-cell;
	width: 100%;
	height: 100%;
}
.center{
	vertical-align: middle;
}
.ripple1, .ripple2, .ripple3{
	position: absolute;
	left: 50vw;
	background-image: radial-gradient(ellipse farthest-corner at 45px 45px, #00ffff 0%, rgba(0, 0, 255, 0) 50%, #0000ff 95%);
	background-position: center center;
	-webkit-animation: radar 5s ease infinite;
	-moz-animation: radar 5s ease infinite;
	animation: radar 5s ease infinite;
	-webkit-border-radius: 100%;
	-webkit-background-clip: padding-box;
	-moz-border-radius: 100%;
	-moz-background-clip: padding;
	border-radius: 100%;
	background-clip: padding-box;
}
.ripple2{
	-webkit-animation-delay: 0.3s;
	animation-delay: 0.3s;
}
.ripple3{
	-webkit-animation-delay: 0.6s;
	animation-delay: 0.6s;
}
@-webkit-keyframes GradientAnimation{
	0%{
		background-position: 0% 48%;
	}
	50%{
		background-position: 100% 53%;
	}
	100%{
		background-position: 0% 48%;
	}
}
@-moz-keyframes GradientAnimation{
	0% {
    background-position: 0% 48%;
  	}
  	50% {
    	background-position: 100% 53%;
  	}
 	100% {
    	background-position: 0% 48%;
  	}
}
@keyframes GradientAnimation{
	0% {
    	background-position: 0% 48%;
  	}
  	50% {
    	background-position: 100% 53%;
  	}
  	100% {
    	background-position: 0% 48%;
  	}
}

@keyframes radar{
	1%{
		width: 0vh;
		height: 0vh;
		margin-left: 0vh;
		margin-top: 0vh;
	}
	100%{
		width: 200vh;
		height: 200vh;
		margin-left: -100vh;
		margin-top: -100vh;
	}
}
@-webkit-keyframes radar{
	1% {
    	width: 0vw;
    	height: 0vw;
    	margin-left: 0vw;
    	margin-top: 0vw;
  	}
  	100% {
    	width: 200vw;
    	height: 200vw;
    	margin-left: -100vw;
    	margin-top: -100vw;
  	}
}


.body {
	height:100px;
	margin:auto;
	width: 100%;
	font-family: "Exo", sans-serif;
	color: #fff;
	background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
	background-size: 400% 400%;
	animation: gradientBG 15s ease infinite;
}
.footer{
    width:100%;
    height: 100px;
    background: linear-gradient(45deg,#F17C58,#E94584,#24AADB,#27DBB1,#FFDC18,#FF3706);
	position: fixed;
	bottom: 0;
	background-size: 400% 400%;
	animation: gradientBG 15s ease infinite;
	color: #fff;
	text-align:center;
}	
@keyframes gradientBG {
	0% {
		background-position: 0% 50%;
	}
	50% {
		background-position: 100% 50%;
	}
	100% {
		background-position: 0% 50%;
	}
}

.container {
	width: 100%;
	position: absolute;
	top: 35%;
	text-align: center;
}

h1 {
	font-weight: 300;
}

h3 {
	color: #eee;
	font-weight: 100;
}

h5 {
	color:#eee;
	font-weight:300;
}

a,
a:hover {
	text-decoration: none;
	color: #ddd;
}

.box{
width:100%;
height:100px;
margin:auto;
}
#header-wrap{
	height:100px;
	color:#f50303;
	width:100%;
	border-bottom:1px solid;
	background-color:yellow;
	font-size: 30px;
	border: 1px dashed orange;
	position: fixed;
	text-align: center;
}
#header{
	margin:0 auto;
	width:1000px;
	height:100px;
	
}
#header-logo{
	float: left;
    width: 100px;
    height: 100px;
    background-color: #136D9F;
    text-align: center;
	padding-top:0px;
	border-radius: 100%;
}
#header-picture{
    float: right;
    padding-left: 10px;
    text-align: right
}
#img1{

}
.red{
position: fixed;
top: 0;
background:#f00;
}
.green{
position: fixed;
bottom: 0;
background:#0f0;
}
.blue{
background:#00f;
}

</style>

<body>
<!--header-->
<!--div id="header-wrap">
	<!--div class="box red"-->
	<div class="body">
		<img id = "header-logo" src="sos.png" height="95px" width="95px" ><p></p><p font-size:8>Emergency traffic control system</p>
	<h1>Project green corridor</h1>
	<g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal"><path d="M0,172v-172h172v172z" fill="none"></path><g fill="#eeeeee"><path d="M143.19336,21.43001c-0.26705,0.00844 -0.53341,0.03181 -0.79785,0.06999h-34.89551c-2.58456,-0.03655 -4.98858,1.32136 -6.29153,3.55376c-1.30295,2.2324 -1.30295,4.99342 0,7.22582c1.30295,2.2324 3.70697,3.59031 6.29153,3.55376h18.53256l-66.59961,66.59961c-1.8722,1.79752 -2.62637,4.46674 -1.97164,6.97823c0.65473,2.51149 2.61604,4.4728 5.12753,5.12753c2.51149,0.65473 5.18071,-0.09944 6.97823,-1.97165l66.59961,-66.59961v18.53255c-0.03655,2.58456 1.32136,4.98858 3.55376,6.29153c2.2324,1.30295 4.99342,1.30295 7.22582,0c2.2324,-1.30295 3.59031,-3.70697 3.55376,-6.29153v-34.9235c0.28889,-2.08845 -0.35639,-4.19816 -1.76411,-5.76769c-1.40772,-1.56953 -3.43507,-2.43964 -5.54253,-2.3788zM35.83333,21.5c-7.83362,0 -14.33333,6.49972 -14.33333,14.33333v100.33333c0,7.83362 6.49972,14.33333 14.33333,14.33333h100.33333c7.83362,0 14.33333,-6.49972 14.33333,-14.33333v-43c0.03655,-2.58456 -1.32136,-4.98858 -3.55376,-6.29153c-2.2324,-1.30295 -4.99342,-1.30295 -7.22582,0c-2.2324,1.30295 -3.59031,3.70697 -3.55376,6.29153v43h-100.33333v-100.33333h43c2.58456,0.03655 4.98858,-1.32136 6.29153,-3.55376c1.30295,-2.2324 1.30295,-4.99342 0,-7.22582c-1.30295,-2.2324 -3.70697,-3.59031 -6.29153,-3.55376z"></path></g></g></svg></a></h3>
</div>
<div id="1">
		<center>
			<table>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			 <tr><td> <h1>Login ID<h1></td><td> <input type="text" name="login"></td></tr>
			 <tr><style> input[type=text]{width: 100%; padding: 12px 12px; margin: 6px 0px; box-sizing: border box}</style> </tr>
			 <tr><td> <h1>Password</h1></td><td><input type="Password"  name="pass"> </td> </tr>
			 <tr><style> input[type=password]{width: 100%; padding: 12px 12px; margin: 6px 0px; box-sizing: border box}</style> </tr>	
			 <tr><td><input type="SUBMIT" value="SUBMIT"> </td><td><input type="RESET" value="RESET"></td>  </tr>
			 <tr><style> input[type=SUBMIT]{width: 100%; padding: 6px 6px; margin: 8px 0px; box-sizing: border box}</style> </tr>
			 <tr><style> input[type=reset]{width: 100%; padding: 6px 6px; margin: 8px 0px; box-sizing: border box}</style> </tr>	
			</table>
		</center>
</div> 
<div class="footer">
<p>SHANKAR P. KHARAT</p>
<p>RAVI GAVDE</p>
<p>PRATIKSHA R. PANDE</p>
</div>
</html>
  """)
def select(request):
	return httpresponse("")
