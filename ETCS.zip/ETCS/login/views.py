from django.shortcuts import render
from django.http import HttpResponse
from django import forms
from django.http import HttpResponseRedirect
import urllib.request, json
import time

    	
def login(request):
    return render(request, 'trial.html')
def SELECT(request):
		data = request.POST['login']
		passs = request.POST['pass']
		if data=='etcs' and passs=='etcs123':
				
				return render(request, 'SELECT.html')
		else:
				data='INVALID PASSWORD OR USERNAME'
				return render(request, 'trial.html', {'data':data})				
		
def MAP(request):	
		origin = str(request.POST['start'])
		destination = str(request.POST['end'])
		listt=cal(origin,destination)
		distance=float(listt[2])
		if distance > 50:
				mess='CANNOT COMPUTE FOR DISTANCE GREATER THAN 50 KM'
				return render(request, 'SELECT.html',{'mess':mess})
		else:					
				return render(request, 'MAP.html',{'start' :origin, 'data' :destination,'dist':listt[2],'time':listt[1] })

def cal(o,d):
		endpoint = 'https://maps.googleapis.com/maps/api/directions/json?'
		api_key = 'API_KEY'
		origin = o.replace(' ','+')
		destination = d.replace(' ','+')
		nav_request = 'origin={}&destination={}&key={}'.format(origin,destination,api_key)
		request = endpoint + nav_request
		response = urllib.request.urlopen(request).read()
		directions = json.loads(response)
		#print(directions)
		#Extracting json data
		#the syntax is: mydict[key] = "value"
		routes=directions['routes']
		bounds=routes[0]
		legs=bounds['legs']
		legger=legs[0]
		durationlist=legger['duration']
		distancelist=legger['distance']
		distancestr=distancelist['text']
		durationstr=durationlist['text']
		distancem=distancestr.split()
		distance=distancem[0]
		#durationstr='9 hours 2 mins'
		l=durationstr.split()
		hour=l[0]
		minute=l[0]			
		return [hour,minute,distance]
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				 	
